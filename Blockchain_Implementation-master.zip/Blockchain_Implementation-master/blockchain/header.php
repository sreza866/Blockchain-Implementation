<div class='container-fluid'>
<div class="row" style='height:70px;background-color:blue'>
  <div class="col-sm-12">
   <h2 align='center' style='margin-top:10px'><font color='white'>Welcome To Registry Office</font></h2>
  </div>
</div>
</div>